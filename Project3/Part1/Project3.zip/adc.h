


#ifndef _ADC_H    /* Guard against multiple inclusion */
#define _ADC_H


void initADC();



#define ADC_FLAG IFS0bits.AD1IF

#define ADC_BUFF ADC1BUF0





#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
