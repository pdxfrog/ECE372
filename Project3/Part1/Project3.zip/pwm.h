
#ifndef _PWM_H    /* Guard against multiple inclusion */
#define _PWM_H



void initPWM();





#endif /* _PWM_H */

/* *****************************************************************************
 End of File
 */
