
#ifndef _LOCK_H    /* Guard against multiple inclusion */
#define _LOCK_H


extern char codes[5][4];

unsigned char isValid(char* code);







#endif /* _LOCK_H */


