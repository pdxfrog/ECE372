


#include <xc.h>
#include "global_defines.h"
#include "lock.h"




char code[5][4] = {0};

